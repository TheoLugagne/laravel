<!DOCTYPE html>
<html>
<head>
    <title>New Grade Notification</title>
</head>
<body>
<h1>New Grade Notification</h1>
<p>Dear Student,</p>
<p>A new grade has been entered:</p>
<ul>
    <li>Grade: {{ $grade }}</li>
    <li>Date: {{ $date }}</li>
</ul>
<p>Best regards,</p>
<p>Your School</p>
</body>
</html>
